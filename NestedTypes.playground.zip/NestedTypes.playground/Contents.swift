import Cocoa

var greeting = "Hello, Hello, Hello"

//HERENCA -> RELACAO DO TIPO É UM
//NESTED TYPES/ COMPOSICAO -> RELACAO DO TIPO TEM UM

//MARK: - NESTED TYPES

//MARK: - Example 1

struct Car {
    
    var engine: Engine
    var wheels: Wheels
    
    struct Engine {
        
        var state: State = .stopped
        var fuelType: FuelType = .gasoline
        
        enum State {
            case started, stopped
        }
        enum FuelType {
            case gasoline, diesel, electric
        }
    }
    
    struct Wheels {
        var size: WheelSize = .medium
        
        enum WheelSize {
            case small, medium, large
        }
    }
}

let myCar = Car(engine: Car.Engine(state: .started, fuelType: .diesel), wheels: Car.Wheels())


// MARK: - Example 2

class Account {
    
    var savings: SavingsAccount?
    var current: CurrentAccount?
    
    class Card {
        var accountNumber: String
        var password: String
        var black: Bool?
        
        init(accountNumber: String, password: String, black: Bool? = false) {
            self.accountNumber = accountNumber
            self.password = password
            self.black = black
        }
    }
    
    class SavingsAccount { //poupanca
        var balance: Double
        var card: Card
        
        
        init(balance: Double, card: Card) {
            self.balance = balance
            self.card = card
        }
        
        func getBalance() -> Double {
            return balance
        }
        
        func deposit(_ value: Double) { //depositar
            balance += value
        }
        
        func withdraw(_ value: Double) -> Double? {
            if balance >= value {
                balance -= value
                return value
            } else {
                print("No money enough to withdraw")
                return nil
            }
        }
    }
    
    class CurrentAccount { //corrente
        var balance: Double
        var overdraftLimit: Double
        var card: Card
        
        
        init(balance: Double, overdraftLimit: Double = 100, card: Card) {
            self.balance = balance
            self.overdraftLimit = overdraftLimit
            self.card = card
        }
        
        func getBalance() -> Double {
            return balance
        }
        
        func deposit(_ value: Double) { //depositar
            balance += value
        }
        
        func withdraw(_ value: Double) -> Double? {
            if balance >= value {
                balance -= value
                return value
            } else {
                print("No money enough to withdraw")
                return nil
            }
        }
    }
}

// Exemplo de uso 1:

let myAccount = Account()
let card = Account.Card(accountNumber: "123456", password: "password")
myAccount.savings = Account.SavingsAccount(balance: 100.0, card: card)
myAccount.current = Account.CurrentAccount(balance: 200.0, overdraftLimit: 200.0, card: card)

// Exemplo de uso 2:

let myBlackAccount = Account()
let blackCard = Account.Card(accountNumber: "654321", password: "passwordDiferent", black: true)
myBlackAccount.savings = Account.SavingsAccount(balance: 1000.0, card: blackCard)
myBlackAccount.current = Account.CurrentAccount(balance: 2000.0, overdraftLimit: 5000.0, card: blackCard)

myBlackAccount.current?.deposit(100)
print(myBlackAccount.current?.getBalance() ?? 0)
let comprarSorveteCaro = myBlackAccount.current?.withdraw(50)
print(myBlackAccount.current?.getBalance() ?? 0)
