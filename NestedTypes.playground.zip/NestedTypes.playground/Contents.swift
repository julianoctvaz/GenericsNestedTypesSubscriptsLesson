import Cocoa

var greeting = "Hello, Hello, Hello"

//MARK: - NESTED TYPES

//MARK: - Example 1

struct Car {
    struct Engine {
        enum State {
            case started, stopped
        }
        enum FuelType {
            case gasoline, diesel, electric
        }
        var state: State = .stopped
        var fuelType: FuelType = .gasoline
    }
    
    struct Wheels {
        enum WheelSize {
            case small, medium, large
        }
        var size: WheelSize = .medium
    }
    
    var engine: Engine
    var wheels: Wheels
}

let myCar = Car(engine: Car.Engine(state: .started, fuelType: .diesel), wheels: Car.Wheels())

// MARK: - Example 2

class Account {
    
    var savings: SavingsAccount? // variaveis aux para poupanca
    var current: CurrentAccount? // variaveis aux para corrente
    
    class Card {
        var accountNumber: String
        var password: String
        var black: Bool?
        
        init(accountNumber: String, password: String, black: Bool? = false) {
            self.accountNumber = accountNumber
            self.password = password
            self.black = black
        }
    }
    
    class SavingsAccount { //poupanca
        var balance: Double
        var card: Card
        
        
        init(balance: Double, card: Card) {
            self.balance = balance
            self.card = card
        }
        
        func deposit(_ value: Double) { //depositar
            balance += value
        }
        
        func withdraw (_ value: Double) -> Double? {
            if balance >= value {
                balance -= value
                return value
            } else {
                print("No money enough to withdraw")
                return nil
            }
        }
    }
    
    class CurrentAccount { //corrente
        var balance: Double
        var overdraftLimit: Double
        var card: Card
        
        
        init(balance: Double, overdraftLimit: Double = 100, card: Card) {
            self.balance = balance
            self.overdraftLimit = overdraftLimit
            self.card = card
        }
        
        func deposit(_ value: Double) { //depositar
            balance += value
        }
        
        func withdraw (_ value: Double) -> Double? {
            if balance >= value {
                balance -= value
                return value
            } else {
                print("No money enough to withdraw")
                return nil
            }
        }
    }
}

// Exemplo de uso 1:

let card = Account.Card(accountNumber: "123456", password: "password")
let savingsAccount = Account.SavingsAccount(balance: 100.0, card: card)
let currentAccount = Account.CurrentAccount(balance: 200.0, overdraftLimit: 100.0, card: card)

let myAccount = Account()
myAccount.savings = savingsAccount
myAccount.current = currentAccount

// Exemplo de uso 2:

let myBlackAccount = Account()
myBlackAccount.savings = savingsBlackAccount
myBlackAccount.current = currentBlackAccount

let blackCard = Account.Card(accountNumber: "654321", password: "passwordDiferent", black: true)
let savingsBlackAccount = Account.SavingsAccount(balance: 1000.0, card: blackCard)
let currentBlackAccount = Account.CurrentAccount(balance: 2000.0, overdraftLimit: 5000.0, card: card)

myBlackAccount.current?.deposit(100)
let comprarSorveteCaro = myBlackAccount.current?.withdraw(50)
