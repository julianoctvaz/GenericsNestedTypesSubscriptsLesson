import Cocoa

var greeting = "Hello, world, Hello, Subscript"

// MARK: - Example 1

struct Divider {
    let number: Int
    
    subscript(value: Int) -> Int {
        return number / value
    }
}
let division = Divider(number: 100)

print("The number can be divided up to \(division[9]) times")
print("The number can be divided up to \(division[2]) times")


// MARK: - Example 2

struct Matrix {
    var data: [[Double]]
    subscript(row: Int, column: Int) -> Double {
        get {
            return data[row][column]
        }
        set {
            data[row][column] = newValue
        }
    }
}

var matrix = Matrix(data: [[1.0, 2.0], [3.0, 4.0]])
/**
 (1,0) (2.0)
 (3.0) (4.0)
 **/

print(matrix[0, 1]) // Output: 2.0, accessing the element at the first row and second column

// Setting the value of the element at the first row and second column to 5.0
matrix[0, 1] = 5.0

print(matrix[0, 1]) // Output: 5.0, reflecting the updated value

// MARK: - Example 3

struct SafeArray<T> {
    private var items: [T]
    
    init(_ items: [T]) {
        self.items = items
    }
    
    subscript(index: Int) -> T? {
        return (index >= 0 && index < items.count) ? items[index] : nil
    }
}

let safeNumbers = SafeArray([10, 20, 30])
print(safeNumbers[1] ?? "Índice fora do alcance") // Output: 20
print(safeNumbers[5] ?? "Índice fora do alcance") // Output: Índice fora do alcance


// MARK: - Example 4 with Generics

struct SafeMatrix<T> {
    private var data: [[T]]
    
    init(_ data: [[T]]) {
        self.data = data
    }
    
    subscript(row: Int, column: Int) -> T? {
        if row >= 0 && row < data.count && column >= 0 && column < data[row].count {
            return data[row][column]
        } else {
            return nil
        }
    }
}
let unsafeMatrix = Matrix(data: [[1, 2, 3], [4, 5, 6], [7, 8, 9]])
/**
 (1) (2) (3)
 (4) (5) (6)
 (7) (8) (9)
 **/
let safedMatrix = SafeMatrix(unsafeMatrix.data)

print(unsafeMatrix[0, 2]) // Output: 3.0
print(unsafeMatrix[2, 2]) // Output: 9.0
//print(unsafeMatrix[3, 2]) // Output: Error! May you use ?? nil into the print to avoid it? with unsafeMatrix you cant. Only with safedMatrix.

print(safedMatrix[0, 2] as Any) // Output: Optional(3)
print(safedMatrix[2, 2] as Any) // Output: Optional(9)
print(safedMatrix[3, 2] as Any) // Output: nil, out of bounds


// MARK: - Example 5 with two Subscripts, SUPRISE! 👀

struct MultiSubscriptMatrix {
    var data: [[Double]]
    
    subscript(row: Int, column: Int) -> Double? {
        get {
            guard row >= 0, row < data.count, column >= 0, column < data[row].count else { return nil }
            return data[row][column]
        }
        set {
            guard let newValue = newValue, row >= 0, row < data.count, column >= 0, column < data[row].count else { return }
            data[row][column] = newValue
        }
    }
    
    subscript(row: Int) -> [Double]? {
        get {
            guard row >= 0, row < data.count else { return nil }
            return data[row]
        }
        set {
            guard let newValue = newValue, row >= 0, row < data.count else { return }
            data[row] = newValue
        }
    }
}

var multiMatrix = MultiSubscriptMatrix(data: [[1.0, 2.0, 3.0], [4.0, 5.0, 6.0], [7.0, 8.0, 9.0]])

print(multiMatrix[1, 2] as Any)
print(multiMatrix[1] as Any)

